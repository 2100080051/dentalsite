//animation
new WOW().init();   

